--Script made by: LordExploit

--Please dont skid rip this and take credit for it just accept it :(

loadstring(game:HttpGet('https://raw.githubusercontent.com/NecessaryPaint/ur-mom/master/CBRO_Modded_Weapons.lua', true))()
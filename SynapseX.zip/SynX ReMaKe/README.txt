Welcome to Synapse X!

To install, please first whitelist this folder in your computer's anti-virus/anti-malware software.

Afterwards, launch "Synapse X.exe" and register with the key that was provided with your purchase. All other installation tasks are automated from there. Enjoy!

-Synapse X Development Team